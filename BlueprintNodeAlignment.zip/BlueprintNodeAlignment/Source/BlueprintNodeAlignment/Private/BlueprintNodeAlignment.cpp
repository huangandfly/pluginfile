// Copyright [2024/10/14 huangandfly]

#include "BlueprintNodeAlignment.h"

#include "BlueprintEditor.h"

#include "Framework/Commands/Commands.h"
#include "Framework/Commands/InputChord.h"
#include "Framework/Commands/UICommandInfo.h"
#include "Framework/Docking/TabManager.h"
#include "InputCoreTypes.h"

#include "BlueprintEditorModule.h"
#include "SGraphPanel.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"

#define LOCTEXT_NAMESPACE "FBlueprintNodeAlignmentModule"

// 横向间隔
#define Horizontal_Intervals 20
// 纵向间隔
#define Vertical_Intervals 20

void FBlueprintNodeAlignmentModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
}

void FBlueprintNodeAlignmentModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

void UBlueprintNodeAlignmentSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);


	UAssetEditorSubsystem* AssetEditorSubsystem = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
	AssetEditorSubsystem->OnAssetEditorOpened().AddUObject(this, &UBlueprintNodeAlignmentSubsystem::AssetEditorOpened);

	FAdditionGraphEditorCommands::Register();

	PluginCommands = MakeShareable(new FUICommandList);

	PluginCommands->MapAction(
		FAdditionGraphEditorCommandsImpl::Get().MyNodeAlignment,
		FExecuteAction::CreateUObject(this, &UBlueprintNodeAlignmentSubsystem::AlignBlueprintNodes));

	PluginCommands->MapAction(
		FAdditionGraphEditorCommandsImpl::Get().MySelectionLinkNode,
		FExecuteAction::CreateUObject(this, &UBlueprintNodeAlignmentSubsystem::SelectionBlueprintNodes));
}

void UBlueprintNodeAlignmentSubsystem::Deinitialize()
{
	Super::Deinitialize();
}

void UBlueprintNodeAlignmentSubsystem::AssetEditorOpened(UObject* Object)
{
	//if( !BlueprintEditorModule )
	//{
	//	BlueprintEditorModule = &FModuleManager::LoadModuleChecked<FBlueprintEditorModule>("Kismet");
	//}

	//TArray<TSharedRef<IBlueprintEditor>> BES = BlueprintEditorModule->GetBlueprintEditors();

	UAssetEditorSubsystem* AssetEditorSubsystem = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
	IAssetEditorInstance* EditorIns = AssetEditorSubsystem->FindEditorForAsset(Object, false);

	FBlueprintEditor* BlueprintEditor = static_cast<FBlueprintEditor*>(EditorIns);
	if (!BlueprintEditor) return;

	BlueprintEditor->GetToolkitCommands()->Append(PluginCommands->AsShared());
}

void UBlueprintNodeAlignmentSubsystem::PreAction(TSharedPtr<SGraphEditor>& GraphEditor, BlueprintEditorData& OutData)
{
	TSharedPtr<SDockTab> tab = FGlobalTabmanager::Get()->GetActiveTab();
	if (!tab.IsValid())
		return;

	const TSharedPtr<SWidget> Content = tab->GetContent();
	if (Content->GetType() != TEXT("SGraphEditor"))
		return;

	GraphEditor = StaticCastSharedPtr<SGraphEditor>(Content);
	if (!GraphEditor.IsValid())
		return;

	FChildren* Child = GraphEditor->GetGraphPanel()->GetAllChildren();
	int32 MaxNum = Child->Num();
	for (int32 i = 0; i < MaxNum; i++)
	{
		const TSharedRef<SWidget>& Node = Child->GetChildAt(i);
		const TSharedRef<SNodePanel::SNode>& NodeToAdd = StaticCastSharedRef<SNodePanel::SNode>(Node);
		OutData.NodeToWidgetLookup.Add(NodeToAdd->GetObjectBeingDisplayed(), NodeToAdd);
	}
}

void UBlueprintNodeAlignmentSubsystem::AlignBlueprintNodes()
{
	const FScopedTransaction Transaction(LOCTEXT("AlignBPNodes", "Align Blueprint Nodes"));
	
	BlueprintEditorData EditorToData;
	TSharedPtr<SGraphEditor> GraphEditor;
	PreAction(GraphEditor, EditorToData);

	if (!GraphEditor.IsValid())
		return;

	FGraphPanelSelectionSet SelectionSet = GraphEditor->GetSelectedNodes();
	// SGraphPanel::StraightenConnections() 参考按Q 对齐节点。
	// 主要是先找到每个节点的in,out节点，再移动位置
	// 目前思路是，整理选择的当前节点及以后的所有的节点，每个节点包含in节点和out节点
	// 需要定义个结构体，存下每个节点的宽高数据，这个很重要。
	// 获得节点宽高数据，使用SGraphEditorImpl.cpp里GetNodeSize全局函数获取
	for (auto& It : SelectionSet)
	{
		UEdGraphNode* SourceNode = Cast<UEdGraphNode>(It);
		if (!SourceNode)
			continue;

		TemporaryData Data = {&EditorToData, GraphEditor};
		TSharedPtr<FGraphNode> HeadNode = MakeShared<FGraphNode>();
		HeadNode->bRootNode = true;
		HeadNode = LinkNode(HeadNode, SourceNode, Data);

		AlignmentNode(HeadNode);
		SetNodeSelection(GraphEditor, HeadNode);
	}
}

void UBlueprintNodeAlignmentSubsystem::SelectionBlueprintNodes()
{
	BlueprintEditorData EditorToData;
	TSharedPtr<SGraphEditor> GraphEditor;
	PreAction(GraphEditor, EditorToData);

	if (!GraphEditor.IsValid())
		return;

	FGraphPanelSelectionSet SelectionSet = GraphEditor->GetSelectedNodes();
	for (auto& It : SelectionSet)
	{
		UEdGraphNode* SourceNode = Cast<UEdGraphNode>(It);
		if (!SourceNode)
			continue;

		TemporaryData Data = {&EditorToData, GraphEditor};
		Data.bSelectionNode = true;

		TSharedPtr<FGraphNode> HeadNode = MakeShared<FGraphNode>();
		HeadNode->bRootNode = true;
		HeadNode = LinkNode(HeadNode, SourceNode, Data);
		SetNodeSelection(GraphEditor, HeadNode);
	}
}

void UBlueprintNodeAlignmentSubsystem::AlignmentNode(TSharedPtr<FGraphNode> HeadNode)
{
	if (!HeadNode.IsValid())
		return;

	// 先处理输入引脚
	AlignmentInputDataNode(HeadNode);

	// 处理执行输出引脚
	AlignmentOutputExecuteNode(HeadNode);
}

void UBlueprintNodeAlignmentSubsystem::AlignmentInputDataNode(TSharedPtr<FGraphNode> Node)
{
	if (!Node.IsValid())
		return;

	// 有多个输入节点的纯函数节点，暂时不处理
	if (IsMultipleInputNode(Node))
		return;

	for (auto& Pin : Node->InputData)
	{
		TSharedPtr<FPinData> PData = Pin;

		UEdGraphPin* DstGraphPin = PData->DstPin->GetPinObj();
		UEdGraphPin* SrcGraphPin = PData->SrcPin->GetPinObj();
		if (!DstGraphPin || !SrcGraphPin)
		{
			continue;
		}

		UK2Node* DstGraphNode = Cast<UK2Node>(DstGraphPin->GetOwningNode());
		UK2Node* SrcGraphNode = Cast<UK2Node>(SrcGraphPin->GetOwningNode());
		if (!DstGraphNode || !SrcGraphNode)
		{
			continue;
		}

		// InputPin的Node不是纯函数，不做处理，其实就是从DstGraphNode节点返回出来的值或者是函数入口的input值
		if (!DstGraphNode->IsNodePure())
			continue;

		float NewNodePosX = 0;
		float NewNodePosY = 0;
		if (!SrcGraphNode->IsNodePure())
		{
			float AlignmentDelta = (SrcGraphNode->NodePosY + PData->SrcPin->GetNodeOffset().Y) -
				(DstGraphNode->NodePosY + PData->DstPin->GetNodeOffset().Y);
			NewNodePosY = DstGraphNode->NodePosY + AlignmentDelta;
			NewNodePosX = SrcGraphNode->NodePosX - DstGraphNode->NodeWidth - Horizontal_Intervals;

			// 已经有值了，不是第一个输入节点
			if (Node->InputNodeBoundBox.bIsValid)
			{
				// 跟之前的输入节点是否有交叉
				bool bIntersecting = AreRectanglesIntersecting(Node->InputNodeBoundBox,
				                                               FVector2D(NewNodePosX, NewNodePosY),
				                                               FVector2D(DstGraphNode->NodeWidth,
				                                                         DstGraphNode->NodeHeight));

				// 现在处理的这个节点和上面的节点重叠了
				if (bIntersecting)
				{
					NewNodePosY = Node->InputNodeBoundBox.Max.Y + 10;
				}
			}
			// 第一个
			else if (NewNodePosY < Node->Node->NodePosY + Node->InputExecNodeOffsetPos.Y + 10)
			{
				NewNodePosY = Node->Node->NodePosY + Node->InputExecNodeOffsetPos.Y + 10;
			}
		}
		else
		{
			NewNodePosY = SrcGraphNode->NodePosY + SrcGraphNode->NodeHeight + 2;
			NewNodePosX = (SrcGraphNode->NodePosX + SrcGraphNode->NodeWidth) - DstGraphNode->NodeWidth;
		}


		float DeltaX = NewNodePosX - PData->GNode->Node->NodePosX;
		float DeltaY = NewNodePosY - PData->GNode->Node->NodePosY;
		SetNodePos(PData->GNode, NewNodePosX, NewNodePosY);

		// 有多个输入节点的纯函数节点，不往下折叠了，整个后续节点都相对跟随当前节点移动
		if (IsMultipleInputNode(PData->GNode))
		{
			AdjustInputNodeRelativePos(PData->GNode, DeltaX, DeltaY);
		}
		else
		{
			AlignmentInputDataNode(PData->GNode);
		}

		Node->InputNodeBoundBox += PData->GNode->InputNodeBoundBox;
	}
}

void UBlueprintNodeAlignmentSubsystem::SetInputNodePos(TSharedPtr<FGraphNode> GNode, float OwnerNodeOffsetX)
{
	for (auto& Pin : GNode->InputData)
	{
		TSharedPtr<FPinData> PData = Pin;
		if (!PData.IsValid() || !PData->GNode.IsValid())
			continue;

		UK2Node* K2Node = Cast<UK2Node>(PData->GNode->Node);
		if (!K2Node)
			continue;

		// 不是纯函数，不动
		if (!K2Node->IsNodePure())
			continue;

		float NewNodePosX = OwnerNodeOffsetX - PData->GNode->Node->NodeWidth - Horizontal_Intervals;
		float DeltaX = NewNodePosX - PData->GNode->Node->NodePosX;
		SetNodePos(PData->GNode, NewNodePosX, PData->GNode->Node->NodePosY);

		// 有多个输入节点，不往下折叠了，整个后续节点都相对跟随当前节点移动
		if (IsMultipleInputNode(PData->GNode))
		{
			AdjustInputNodeRelativePos(PData->GNode, DeltaX, 0);
		}
		else
		{
			SetInputNodePos(PData->GNode, OwnerNodeOffsetX);
		}
	}
}

void UBlueprintNodeAlignmentSubsystem::AlignmentOutputExecuteNode(const TSharedPtr<FGraphNode> SNode)
{
	if (!SNode.IsValid())
		return;

	// 根据Node节点的输入数据节点的宽度，移动整个节点,每个执行节点为一个整体
	// ！！根节点不移动
	if (!SNode->bRootNode &&
		NeedAdjustPos(SNode) &&
		SNode->Prev.IsValid() &&
		SNode->Prev->SNode.IsValid() &&
		SNode->Prev->SNode->Node)
	{
		const UEdGraphNode* PreNode = SNode->Prev->SNode->Node;

		// 有输入节点多一个空位，否则只需要留出节点到前一个节点的空位即可
		float Intervals = Horizontal_Intervals * 2;
		FBox2D BoundBox = GetPureInputNodeBoundBox(SNode);
		float OffsetX = PreNode->NodePosX + PreNode->NodeWidth + BoundBox.GetSize().X + Intervals;

		SetNodePos(SNode, OffsetX, SNode->Node->NodePosY);

		// 修正输入节点的位置
		SetInputNodePos(SNode, OffsetX);
	}

	TSharedPtr<FGraphNode> PreGraphNode = nullptr;
	for (auto& NextHeadNode : SNode->Next)
	{
		if (!NextHeadNode.IsValid())
			continue;

		if (!NextHeadNode->SNode.IsValid())
			continue;

		// 闭环节点，不处理
		if (NextHeadNode->SNode->bClosedLoopNode)
		{
			PreGraphNode = NextHeadNode->SNode;
			continue;
		}

		if (!NextHeadNode->Pin.IsValid() ||
			!NextHeadNode->SNode->Prev.IsValid() ||
			!NextHeadNode->SNode->Prev->Pin.IsValid())
			continue;

		UEdGraphPin* DstGraphPin = NextHeadNode->Pin->GetPinObj();
		UEdGraphPin* SrcGraphPin = NextHeadNode->SNode->Prev->Pin->GetPinObj();
		if (!DstGraphPin || !SrcGraphPin)
			continue;

		UEdGraphNode* DstGraphNode = DstGraphPin->GetOwningNode();
		UEdGraphNode* SrcGraphNode = SrcGraphPin->GetOwningNode();
		if (!DstGraphNode || !SrcGraphNode)
			continue;

		float AlignmentDelta = (DstGraphNode->NodePosY + NextHeadNode->Pin->GetNodeOffset().Y) -
			(SrcGraphNode->NodePosY + NextHeadNode->SNode->Prev->Pin->GetNodeOffset().Y);

		float NewNodePosX = DstGraphNode->NodePosX + DstGraphNode->NodeWidth + Horizontal_Intervals;
		float NewNodePosY = 0;

		// 有多个输出执行节点，比如Flip Flop,Sequence，当前节点链跟随上一个链的Y排布
		if (PreGraphNode.IsValid())
		{
			FBox2D BoundBox = GetWholeNodeBoundBox(PreGraphNode);
			NewNodePosY = BoundBox.Max.Y + Vertical_Intervals;
		}
		else
		{
			NewNodePosY = SrcGraphNode->NodePosY + AlignmentDelta;
		}

		SetNodePos(NextHeadNode->SNode, NewNodePosX, NewNodePosY);

		AlignmentNode(NextHeadNode->SNode);

		// 遇到有多个输出节点的，当前节点链排布好后，需要根据整条链的高度，重新往下调整
		// 因为每个节点都是跟随前一个节点的位置进行对齐，假如整条链的第一个节点是reroute节点
		// 那么后续节点会和上一个节点链产生重叠，等到当前整条链排布完成后再重新调整
		if (PreGraphNode.IsValid())
		{
			 FBox2D BoundBox = GetWholeNodeBoundBox(NextHeadNode->SNode);
			 float DeltaY = NewNodePosY - BoundBox.Min.Y;
			 AdjustExecuteNodeRelativePos(NextHeadNode->SNode, 0, DeltaY);
		}

		PreGraphNode = NextHeadNode->SNode;
	}
}

void UBlueprintNodeAlignmentSubsystem::SetNodePos(TSharedPtr<FGraphNode> GNode, float NewNodePosX, float NewNodePosY)
{
	if (!GNode.IsValid() || !GNode->Node)
		return;
	
	UEdGraph* GraphObj = GNode->Node->GetGraph();
	if (!GraphObj)
		return;
	
	const UEdGraphSchema* Schema = GraphObj->GetSchema();
	if (!Schema)
		return;
	
	Schema->SetNodePosition(GNode->Node, FVector2D(NewNodePosX, NewNodePosY));

	UK2Node* Node = Cast<UK2Node>(GNode->Node);
	if (!Node)
		return;
	
	// 执行节点不计入输入节点包围盒
	if (!Node->IsNodePure())
		return;
	
	GNode->InputNodeBoundBox = GenerateBox2D(NewNodePosX, NewNodePosY, GNode->Node->NodeWidth, GNode->Node->NodeHeight);
}

bool UBlueprintNodeAlignmentSubsystem::NeedAdjustPos(TSharedPtr<FGraphNode> GNode)
{
	if (!GNode.IsValid() || !GNode->Node)
		return false;

	for (auto& Pin : GNode->InputData)
	{
		TSharedPtr<FPinData> PData = Pin;
		if (!PData.IsValid() || !PData->GNode.IsValid() || !PData->GNode->Node)
			continue;

		UK2Node* Node = Cast<UK2Node>(PData->GNode->Node);
		if (Node->IsNodePure())
			return true;
	}

	return false;
}

void UBlueprintNodeAlignmentSubsystem::MarkClosedLoopNode(TSharedPtr<FGraphNode> GNode, const UEdGraphNode* CurrentNode)
{
	if (!GNode.IsValid() || !CurrentNode)
		return;

	TSharedPtr<FGraphNode> TGNode = GNode;

	while (true)
	{
		if (TGNode->Node == CurrentNode)
		{
			TGNode->bClosedLoopNode = true;
			break;
		}

		TGNode->bClosedLoopNode = true;

		if (!TGNode->Prev.IsValid())
			break;

		TGNode = TGNode->Prev->SNode;
	}
}

bool UBlueprintNodeAlignmentSubsystem::IsMultipleInputNode(TSharedPtr<FGraphNode> GNode)
{
	if (!GNode.IsValid() || !GNode->Node)
		return false;

	UK2Node* Node = Cast<UK2Node>(GNode->Node);
	if (!Node->IsNodePure())
		return false;

	if (GNode->InputData.Num() > 1)
		return true;

	int ValidPin = 0;
	for (auto& Pin : GNode->Node->Pins)
	{
		// 是输入节点，并且节点是公开出来的，比如self，WorldContextObject都不需要手动传参，
		// UGameplayStatics::GetPlayerController节点就有隐藏的WorldContextObject参数
		if (Pin->Direction != EGPD_Input || Pin->bHidden)
			continue;

		// 只要有两个或以上的有效输入节点，那么这个节点的child不进行折叠摆放
		ValidPin++;
		if (ValidPin > 1)
			return true;
	}

	return false;
}

void UBlueprintNodeAlignmentSubsystem::AdjustInputNodeRelativePos(TSharedPtr<FGraphNode> GNode, float DeltaX,
                                                                  float DeltaY)
{
	if (!GNode.IsValid())
		return;

	for (auto& Pin : GNode->InputData)
	{
		TSharedPtr<FPinData> PData = Pin;

		UEdGraphPin* DstGraphPin = PData->DstPin->GetPinObj();
		UEdGraphPin* SrcGraphPin = PData->SrcPin->GetPinObj();
		if (!DstGraphPin || !SrcGraphPin)
		{
			continue;
		}

		UK2Node* DstGraphNode = Cast<UK2Node>(DstGraphPin->GetOwningNode());
		UK2Node* SrcGraphNode = Cast<UK2Node>(SrcGraphPin->GetOwningNode());
		if (!DstGraphNode || !SrcGraphNode)
		{
			continue;
		}

		// InputPin的Node不是纯函数，不做处理，其实就是从DstGraphNode节点返回出来的值或者是函数入口的input值
		if (!DstGraphNode->IsNodePure())
			continue;
		
		SetNodePos(PData->GNode, PData->GNode->Node->NodePosX + DeltaX, PData->GNode->Node->NodePosY + DeltaY);

		AdjustInputNodeRelativePos(PData->GNode, DeltaX, DeltaY);
	}
}

void UBlueprintNodeAlignmentSubsystem::AdjustExecuteNodeRelativePos(TSharedPtr<FGraphNode> GNode, float DeltaX,
                                                                    float DeltaY)
{
	if( !GNode.IsValid() || !GNode->Node )
		return;

	SetNodePos( GNode,GNode->Node->NodePosX + DeltaX, GNode->Node->NodePosY + DeltaY );
	AdjustInputNodeRelativePos( GNode, DeltaX, DeltaY );
	
	for (auto& ExecPin : GNode->Next)
	{
		if (!ExecPin.IsValid() || !ExecPin->SNode.IsValid() || !ExecPin->SNode->Node)
			continue;

		AdjustExecuteNodeRelativePos(ExecPin->SNode,DeltaX,DeltaY);
	}
}

void UBlueprintNodeAlignmentSubsystem::SetNodeSelection(TSharedPtr<SGraphEditor> GraphEditor,
                                                        TSharedPtr<FGraphNode> GNode)
{
	if (!GraphEditor.IsValid())
		return;

	SGraphPanel* GraphPanel = GraphEditor->GetGraphPanel();
	if (!GraphPanel)
		return;

	if (!GNode.IsValid())
		return;

	GraphPanel->SelectionManager.SetNodeSelection(GNode->Node, true);
	SetInputNodeSelection(GraphPanel, GNode);
	SetExecuteNodeSelection(GraphPanel, GNode);
}

void UBlueprintNodeAlignmentSubsystem::SetInputNodeSelection(SGraphPanel* GraphPanel, TSharedPtr<FGraphNode> GNode)
{
	if( !GNode.IsValid() )
		return;
	if( !GraphPanel )
		return;
	
	for (auto& InputData : GNode->InputData)
	{
		// 执行引脚不处理
		UK2Node* Node = Cast<UK2Node>(InputData->GNode->Node);
		if (!Node->IsNodePure())
			continue;

		GraphPanel->SelectionManager.SetNodeSelection(InputData->GNode->Node, true);
		SetInputNodeSelection(GraphPanel, InputData->GNode);
	}
}

void UBlueprintNodeAlignmentSubsystem::SetExecuteNodeSelection(SGraphPanel* GraphPanel, TSharedPtr<FGraphNode> GNode)
{
	for (auto& ExecPin : GNode->Next)
	{
		if (!ExecPin.IsValid() || !ExecPin->SNode.IsValid() || !ExecPin->SNode->Node)
			continue;

		GraphPanel->SelectionManager.SetNodeSelection(ExecPin->SNode->Node, true);
		SetInputNodeSelection(GraphPanel, ExecPin->SNode);
		SetExecuteNodeSelection(GraphPanel, ExecPin->SNode);
	}
}

FVector2D UBlueprintNodeAlignmentSubsystem::GetNodeSize(const SGraphEditor& GraphEditor, const UEdGraphNode* Node)
{
	if (!Node)
	{
		return FVector2D::ZeroVector;
	}

	FSlateRect Rect;
	if (GraphEditor.GetBoundsForNode(Node, Rect, 0.f))
	{
		return FVector2D(Rect.Right - Rect.Left, Rect.Bottom - Rect.Top);
	}

	return FVector2D(Node->NodeWidth, Node->NodeHeight);
}

FBox2D UBlueprintNodeAlignmentSubsystem::GetPureInputNodeBoundBox(TSharedPtr<FGraphNode> GNode)
{
	FBox2D BoundBox;
	
	if( !GNode.IsValid() )
		return BoundBox;
	
	BoundBox.Min = FVector2D(FLT_MAX,FLT_MAX);
	BoundBox.Max = FVector2D(-FLT_MAX,-FLT_MAX);
	
	for (auto& Pin : GNode->InputData)
	{
		TSharedPtr<FPinData> PData = Pin;
		if( !PData.IsValid() )
			continue;
		
		UK2Node* K2Node = Cast<UK2Node>(PData->GNode->Node);
		if (!K2Node)
			continue;
		
		// 不是纯函数，不动
		if (!K2Node->IsNodePure())
			continue;
		
		BoundBox += GenerateBox2D(PData->GNode->Node->NodePosX, PData->GNode->Node->NodePosY,
		                          PData->GNode->Node->NodeWidth, PData->GNode->Node->NodeHeight);
		BoundBox += GetPureInputNodeBoundBox(PData->GNode);
	}
	
	return BoundBox;
}

FBox2D UBlueprintNodeAlignmentSubsystem::GetNodeBoundBox(TSharedPtr<FGraphNode> GNode)
{
	FBox2D BoundBox;
	
	if( !GNode.IsValid() || !GNode->Node)
		return BoundBox;

	BoundBox = GenerateBox2D(GNode->Node->NodePosX,GNode->Node->NodePosY,GNode->Node->NodeWidth,GNode->Node->NodeHeight);
	BoundBox += GetPureInputNodeBoundBox(GNode);

	return BoundBox;
}

FBox2D UBlueprintNodeAlignmentSubsystem::GetWholeNodeBoundBox(TSharedPtr<FGraphNode> GNode)
{
	if( !GNode.IsValid() || !GNode->Node)
		return FBox2D();

	FBox2D BoundBox = GetNodeBoundBox(GNode);
	
	for (auto& NextHeadNode : GNode->Next)
	{
		if (!NextHeadNode.IsValid())
			continue;

		if (!NextHeadNode->SNode.IsValid())
			continue;

		// 闭环节点，不处理
		if (NextHeadNode->SNode->bClosedLoopNode)
			continue;

		BoundBox += GetNodeBoundBox(NextHeadNode->SNode);
	}

	return BoundBox;
}

FVector2D UBlueprintNodeAlignmentSubsystem::GetExecInputPinPos(TSharedPtr<FGraphNode> GNode)
{
	FVector2D Pos( FLT_MIN,FLT_MIN );
	if( !GNode.IsValid() || !GNode->Node )
		return Pos;

	
	
	// 获得输入节点的位置，让出白线
	return FVector2D();
}

void UBlueprintNodeAlignmentSubsystem::ShowNotification(const FText& NotificationText)
{
	// Add a new notification item only if the previous one has expired or is otherwise done fading out (CS_None). This way multiple undo/redo notifications do not pollute the notification window.
	if (!NotificationItem.IsValid() || NotificationItem->GetCompletionState() == SNotificationItem::CS_None)
	{
		FNotificationInfo Info(NotificationText);
		Info.bUseLargeFont = false;
		Info.bUseSuccessFailIcons = true;
		Info.ExpireDuration = 5.0f;

		NotificationItem = FSlateNotificationManager::Get().AddNotification(Info);
	}

	if (NotificationItem.IsValid())
	{
		// Update the text and completion state to reflect current info
		NotificationItem->SetText(NotificationText);
		NotificationItem->SetCompletionState(SNotificationItem::CS_Fail);

		// Restart the fade animation for the current undo/redo notification
		NotificationItem->ExpireAndFadeout();
	}
}

bool UBlueprintNodeAlignmentSubsystem::AreRectanglesIntersecting(const FBox2D& ABox, const FVector2D& BTopLeft,
                                                                 const FVector2D& BSize)
{
	if (!ABox.bIsValid)
		return false;

	FBox2D RectB(BTopLeft, BTopLeft + BSize);

	if (!RectB.bIsValid)
		return false;

	return ABox.Intersect(RectB);
}

TSharedPtr<FGraphNode> UBlueprintNodeAlignmentSubsystem::AddDataPin(TArray<TSharedPtr<FPinData>>& Pins,
                                                                    TSharedPtr<SGraphPin> SrcPin, UEdGraphNode* SrcNode,
                                                                    TSharedPtr<SGraphPin> DesPin, UEdGraphNode* DesNode)
{
	TSharedPtr<FPinData> IPin = MakeShared<FPinData>();
	IPin->GNode = MakeShared<FGraphNode>();
	IPin->GNode->Node = DesNode;
	IPin->SrcPin = SrcPin;
	IPin->DstPin = DesPin;
	Pins.Add(IPin);

	return IPin->GNode;
}

TSharedPtr<FExecPin> UBlueprintNodeAlignmentSubsystem::AddExecPin(TSharedPtr<SGraphPin> Pin, UEdGraphNode* Node)
{
	TSharedPtr<FExecPin> ExecPin = MakeShared<FExecPin>();
	ExecPin->SNode = MakeShared<FGraphNode>();
	ExecPin->SNode->Node = Node;
	ExecPin->Pin = Pin;

	return ExecPin;
}

FBox2D UBlueprintNodeAlignmentSubsystem::GenerateBox2D(float LeftTopX, float LeftTopY, float Width, float Height)
{
	FVector2D Min(LeftTopX, LeftTopY);
	FVector2D Size(Width, Height);
	return FBox2D(Min, Min + Size);
}

TSharedPtr<FGraphNode> UBlueprintNodeAlignmentSubsystem::LinkNode(TSharedPtr<FGraphNode> GNode,
                                                                  UEdGraphNode* SourceNode,
                                                                  TemporaryData& Data)
{
	GNode->Node = SourceNode;
	Data.CacheNodes.Add(SourceNode);

	FVector2D Size = GetNodeSize(*Data.GraphEditor, SourceNode);
	SourceNode->NodeWidth  = Size.X;
	SourceNode->NodeHeight = Size.Y;

	for (UEdGraphPin* SourcePin : SourceNode->Pins) // 使用pintype过滤出pin的类型，input节点如果是exec就不管了，其余输入节点需要对齐
	{
		if (!SourcePin)
			continue;

		TSharedRef<SNodePanel::SNode>* ThisNodePtr = Data.EditorToData->NodeToWidgetLookup.Find(SourceNode);
		if (!ThisNodePtr)
			continue;

		if (SourcePin->LinkedTo.Num() <= 0)
			continue;

		UEdGraphPin* LinkedTo = SourcePin->LinkedTo[0];

		UK2Node* DestNode = LinkedTo ? Cast<UK2Node>(LinkedTo->GetOwningNode()) : nullptr;
		if (!DestNode)
			continue;

		TSharedRef<SNodePanel::SNode>* DestGraphNodePtr = Data.EditorToData->NodeToWidgetLookup.Find(DestNode);
		if (!DestGraphNodePtr)
			continue;

		TSharedPtr<SGraphPin> PinWidget = StaticCastSharedRef<SGraphNode>(*ThisNodePtr)->FindWidgetForPin(SourcePin);
		TSharedPtr<SGraphPin> LinkedPinWidget = StaticCastSharedRef<SGraphNode>(*DestGraphNodePtr)->
			FindWidgetForPin(LinkedTo);

		if (!PinWidget.IsValid() || !LinkedPinWidget.IsValid())
			continue;

		// 节点有宽高属性，但没有设置值，刚好利用此字段
		Size = GetNodeSize(*Data.GraphEditor, DestNode);
		DestNode->NodeWidth  = Size.X;
		DestNode->NodeHeight = Size.Y;

		// 处理的是纯函数输入节点
		if (SourcePin->Direction == EGPD_Input)
		{
			// 执行输入引脚,第一个节点走这
			if (SourcePin->PinType.PinCategory == TEXT("exec"))
			{
				if (GNode->Prev.IsValid())
					continue;

				GNode->Prev = AddExecPin(PinWidget, DestNode);

				// 缓存下执行输入节点的位置
				GNode->InputExecNodeOffsetPos = PinWidget->GetNodeOffset();
				continue;
			}

			// 从函数或者事件入口的outputPin出来的连线，不再递归了，否则死递归
			if (!DestNode->IsNodePure())
				continue;

			TSharedPtr<FGraphNode> AddedNode = AddDataPin(GNode->InputData,
			                                              PinWidget,
			                                              SourceNode,
			                                              LinkedPinWidget,
			                                              DestNode);

			LinkNode(AddedNode, DestNode, Data);
		}
		else if (SourcePin->Direction == EEdGraphPinDirection::EGPD_Output &&
			SourcePin->PinType.PinCategory == TEXT("exec"))
		{
			// 类似FlipFlop这种有多个输出引脚，先把前一条路劲清除掉
			if (GNode->Next.Num() > 0)
			{
				int Index = Data.CacheNodes.IndexOfByKey(SourceNode) + 1;
				Data.CacheNodes.RemoveAt(Index, Data.CacheNodes.Num() - Index);
			}

			// 判断是否是闭环节点链，e.g. A->B->C->A
			// 对于这种链，暂时不处理，没有想到好的方案
			if (Data.CacheNodes.Contains(DestNode))
			{
				MarkClosedLoopNode(GNode, DestNode);

				// 只是选择，不提示
				if (!Data.bSelectionNode)
				{
					ShowNotification(FText::FromString(TEXT("Closed-loop nodes don't handle alignment")));
				}
				continue;
			}

			// 处理的是带执行引脚的输出节点
			// 是另外一条路
			TSharedPtr<FGraphNode> AddedNode = AddDataPin(GNode->OutputData,
			                                              PinWidget,
			                                              SourceNode,
			                                              LinkedPinWidget,
			                                              DestNode);

			// ======= 挂链接
			TSharedPtr<FExecPin> NextPin = MakeShared<FExecPin>();
			NextPin->SNode = AddedNode;
			NextPin->Pin = PinWidget;
			GNode->Next.Add(NextPin);

			TSharedPtr<FExecPin> PrePin = MakeShared<FExecPin>();
			PrePin->SNode = GNode;
			PrePin->Pin = LinkedPinWidget;
			AddedNode->Prev = PrePin;
			// X用前一个节点，Y用当前ownerNode.X位置目前没有用

			// 是否考虑去掉这个变量，每次都重新计算，逻辑就不用那么复杂
			AddedNode->InputExecNodeOffsetPos = LinkedPinWidget->GetNodeOffset();
			// =======

			LinkNode(AddedNode, DestNode, Data);
		}
	}

	return GNode;
}

void FAdditionGraphEditorCommandsImpl::RegisterCommands()
{
	UI_COMMAND(MyNodeAlignment, "Blueprint Node Alignment", "Align nodes on the entire chain",
	           EUserInterfaceActionType::Button, FInputChord(EKeys::A))
	UI_COMMAND(MySelectionLinkNode, "Selection Link Node", "Selection nodes on the entire chain",
	           EUserInterfaceActionType::Button, FInputChord(EKeys::S))
}

void FAdditionGraphEditorCommands::Register()
{
	FAdditionGraphEditorCommandsImpl::Register();
}

const FAdditionGraphEditorCommandsImpl& FAdditionGraphEditorCommands::Get()
{
	// TODO: insert return statement here
	return FAdditionGraphEditorCommandsImpl::Get();
}

void FAdditionGraphEditorCommands::Unregister()
{
	FAdditionGraphEditorCommandsImpl::Unregister();
}


#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FBlueprintNodeAlignmentModule, BlueprintNodeAlignment)
