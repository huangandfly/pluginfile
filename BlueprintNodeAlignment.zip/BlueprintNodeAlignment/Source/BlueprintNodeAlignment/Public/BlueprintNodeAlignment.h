// Copyright huangandfly 2024 All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "SNodePanel.h"
#include "Modules/ModuleManager.h"
#include "Subsystems/SubsystemCollection.h"
#include "BlueprintNodeAlignment.generated.h"

class FBlueprintEditorModule;
class SGraphPin;
class UK2Node;

class FBlueprintNodeAlignmentModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};

struct BlueprintEditorData
{
	TMap<UObject*, TSharedRef<SNodePanel::SNode>> NodeToWidgetLookup;
};

// 纯函数节点
struct FPinData
{
	TSharedPtr<struct FGraphNode> GNode;

	TSharedPtr<SGraphPin> SrcPin;
	TSharedPtr<SGraphPin> DstPin;
};

// 执行引脚Pin
struct FExecPin
{
	TSharedPtr<FGraphNode> SNode = nullptr;
	TSharedPtr<SGraphPin> Pin    = nullptr;
};

struct FGraphNode
{
	// input节点是纯函数节点
	TArray<TSharedPtr<FPinData>> InputData;
	TArray<TSharedPtr<FPinData>> OutputData;
	UEdGraphNode* Node = nullptr;

	// 有执行引脚的节点
	TArray<TSharedPtr<FExecPin>> Next;
	TSharedPtr<FExecPin> Prev = nullptr;

	// 是否是根节点
	bool bRootNode = false;

	// 是否为闭环节点
	bool bClosedLoopNode = false;

	// 输入节点的包围盒，用于重新调整节点时用
	FBox2D InputNodeBoundBox;

	// 输入节点Y方向起始点，一定是低于白线
	FVector2D InputExecNodeOffsetPos = FVector2D::ZeroVector;
};

struct TemporaryData
{
	BlueprintEditorData* EditorToData;
	TSharedPtr<SGraphEditor> GraphEditor;
	// 储存这条链上的节点
	TArray<UEdGraphNode*> CacheNodes;
	// 是否是选择节点
	bool bSelectionNode = false;
};

UCLASS()
class UBlueprintNodeAlignmentSubsystem : public UEditorSubsystem
{
	GENERATED_BODY()

public:
	/** Implement this for initialization of instances of the system */
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;

	/** Implement this for deinitialization of instances of the system */
	virtual void Deinitialize() override;


	void AssetEditorOpened(UObject*);

	// 动作前的准备
	void PreAction(TSharedPtr<SGraphEditor>& GraphEditor, BlueprintEditorData& OutData);
	// 对齐节点处理入口
	void AlignBlueprintNodes();
	// 选择节点处理入口
	void SelectionBlueprintNodes();

	// 链接当前节点之后的所有节点
	TSharedPtr<FGraphNode> LinkNode(TSharedPtr<FGraphNode> GNode,
									UEdGraphNode* SourceNode,
									TemporaryData& Data);

	// 添加普通数据节点
	TSharedPtr<FGraphNode> AddDataPin(TArray<TSharedPtr<FPinData>>& Pins,
	                             TSharedPtr<SGraphPin> SrcPin, UEdGraphNode* SrcNode,
	                             TSharedPtr<SGraphPin> DesPin, UEdGraphNode* DesNode);

	// 添加一个执行节点
	TSharedPtr<FExecPin> AddExecPin(TSharedPtr<SGraphPin> Pin, UEdGraphNode* Node);

	// 创建一个Box2D
	FBox2D GenerateBox2D(float LeftTopX, float LeftTopY, float Width, float Height);

	// 对齐节点入口
	void AlignmentNode(TSharedPtr<FGraphNode> HeadNode);

	// 输入数据节点对齐
	void AlignmentInputDataNode(TSharedPtr<FGraphNode> Node);

	// 执行节点对齐，（带白色线的执行引脚）
	void AlignmentOutputExecuteNode(TSharedPtr<FGraphNode> Node);

	// 设置节点的位置
	void SetNodePos(TSharedPtr<FGraphNode> GNode, float NewNodePosX, float NewNodePosY);

	// 重新修正输入节点的位置
	void SetInputNodePos(TSharedPtr<FGraphNode> GNode,float OwnerNodeOffsetX);

	// 是否需要重新调整位置
	bool NeedAdjustPos(TSharedPtr<FGraphNode> GNode);

	// 标记闭环节点
	void MarkClosedLoopNode(TSharedPtr<FGraphNode> GNode, const UEdGraphNode* Node);

	// 是否是有多个输入节点的Pure函数节点，这种节点不对后续输入节点进行处理，开发者自行处理吧，情况太复杂了
	bool IsMultipleInputNode(TSharedPtr<FGraphNode> GNode);
	// 调整相对位置，当一个纯函数有多个有效的输入节点时，那与此节点相关联的输入节点只进行相对位置调整，不做对齐方案处理
	void AdjustInputNodeRelativePos(TSharedPtr<FGraphNode> GNode,float DeltaX, float DeltaY);
	void AdjustExecuteNodeRelativePos(TSharedPtr<FGraphNode> GNode,float DeltaX, float DeltaY);

	// 当前处理的节点，设置为选择状态
	void SetNodeSelection(TSharedPtr<SGraphEditor> GraphEditor, TSharedPtr<FGraphNode> GNode);
	// 输入节点选择
	void SetInputNodeSelection(SGraphPanel* GraphPanel, TSharedPtr<FGraphNode> GNode);
	// 执行节点选择
	void SetExecuteNodeSelection(SGraphPanel* GraphPanel, TSharedPtr<FGraphNode> GNode);

	FVector2D GetNodeSize(const SGraphEditor& GraphEditor, const UEdGraphNode* Node);

	// 获得纯输入节点包围盒
	FBox2D GetPureInputNodeBoundBox(TSharedPtr<FGraphNode> GNode);
	// 获得节点包围盒，包含GNode及输入节点
	FBox2D GetNodeBoundBox(TSharedPtr<FGraphNode> GNode);
	// 获得当前节点及之后所有节点的包围盒
	FBox2D GetWholeNodeBoundBox(TSharedPtr<FGraphNode> GNode);
	// 获得执行输入引脚的位置
	FVector2D GetExecInputPinPos(TSharedPtr<FGraphNode> GNode);

	
	// 右下角提示
	void ShowNotification(const FText& NotificationText);


	// Math
	bool AreRectanglesIntersecting(const FBox2D& ABox, const FVector2D& BTopLeft, const FVector2D& BSize);

public:
	FBlueprintEditorModule* BlueprintEditorModule = nullptr;

	TSharedPtr<FUICommandList> PluginCommands;

	TMap<SGraphEditor*, BlueprintEditorData> GraphEditorToData;

	TSharedPtr<class SNotificationItem> NotificationItem;
};

class FUICommandInfo;

class FAdditionGraphEditorCommandsImpl : public TCommands<FAdditionGraphEditorCommandsImpl>
{
public:

	FAdditionGraphEditorCommandsImpl()
		: TCommands<FAdditionGraphEditorCommandsImpl>(TEXT("AdditionGraphEditor"), NSLOCTEXT("Contexts", "AdditionGraphEditor", "Addition Graph Editor"), NAME_None, FAppStyle::GetAppStyleSetName())
	{
	}

	virtual ~FAdditionGraphEditorCommandsImpl()
	{
	}

	virtual void RegisterCommands() override;

	// 节点对齐命令
	TSharedPtr< FUICommandInfo > MyNodeAlignment;
	// 选择整条链上的节点
	TSharedPtr< FUICommandInfo > MySelectionLinkNode;
};

class FAdditionGraphEditorCommands
{
public:
	static void Register();

	static const FAdditionGraphEditorCommandsImpl& Get();

	static void Unregister();
};