﻿using EpicGame;
using Gauntlet;

namespace Travis.Automation
{
	public class TravisGauntletTest : EpicGameTestNode<EpicGameTestConfig>
	{
		public TravisGauntletTest(UnrealTestContext InContext) : base (InContext)
		{
			
		}
		
		public override EpicGameTestConfig GetConfiguration()
		{
			EpicGameTestConfig config = base.GetConfiguration();
			UnrealTestRole Client = config.RequireRole(UnrealTargetRole.Client);
			Client.Controllers.Add("GauntletTestControllerErrorTest");
			// 直接启动配置数量的客户端
			config.RequireRoles(UnrealTargetRole.Client, 1/*config.ClientCount*/);
			// 60 秒后超时，判定为测试失败
			config.MaxDuration = 60;
			config.MaxDurationReachedResult = EMaxDurationReachedResult.Failure;
			config.NoMCP = true;
			
			return config;
		}
	}
}
